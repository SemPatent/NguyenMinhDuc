<?php

    $sqlhost="127.0.0.1"; // Host name
    $sqlusername="root"; // Mysql username
    $sqlpassword=""; // Mysql password
    $db_name="lab1db"; // Database name
    $tbl_name="transactiontb"; // Table name

    $conn = mysql_connect("$sqlhost", "$sqlusername", "$sqlpassword");
    if(! $conn )
    {
        die("COULD NOT CONNECT TO DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
    }

    mysql_select_db("$db_name")or die("COULD NOT SELECT DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");

    // Get values from form
    $TransactionID=$_POST["txtTransactionID"];
    $AccountID=$_POST["txtAccountID"];
    $TransactionTypeID=$_POST["txtTransactionTypeID"];
    $TransactionAmount=$_POST["txtTransactionAmount"];

    $sql="INSERT INTO $tbl_name(Transaction_ID,Account_ID,Transaction_Type_ID,Transaction_Amount)
            VALUES('$TransactionID','$AccountID','$TransactionTypeID','$TransactionAmount')";

    $result=mysql_query($sql);

    // if successfully insert data into database
    if($result){
        header("location:managetransaction.php");
    }
    else{
        die("ERROR EDITTING ACCOUNT:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
        echo "<a href='managetransaction.php'> <em> VIEW TRANSACTION </em> </a>";
    }

    mysql_close($conn);

?>
