<?php

    $id = $_GET['id'];

    $sqlhost="127.0.0.1"; // Host name
    $sqlusername="root"; // Mysql username
    $sqlpassword=""; // Mysql password
    $db_name="lab1db"; // Database name
    $tbl_name="customertb"; // Table name

    $conn = mysql_connect("$sqlhost", "$sqlusername", "$sqlpassword");
    if(! $conn )
    {
        die("COULD NOT CONNECT TO DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
    }

    mysql_select_db("$db_name")or die("COULD NOT SELECT DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");

    // Get values from form
    $CustomerID=$_POST["txtCustomerID"];
    $AddressID=$_POST["txtAddressID"];
    $FirstName=$_POST["txtFirstName"];
    $OtherName=$_POST["txtOtherName"];
    $LastName=$_POST["txtLastName"];
    $BirthDate=$_POST["txtBirthDate"];
    $RegDate=$_POST["txtRegDate"];
    $Telephone=$_POST["txtTelephone"];
    $PassportNumber=$_POST["txtPassportNumber"];

    $sql = "UPDATE $tbl_name SET Customer_ID = '$CustomerID', Address_ID='$AddressID',First_Name='$FirstName',
            Other_Name = '$OtherName', Last_Name='$LastName',Birth_Date='$BirthDate',Reg_Date='$RegDate',
            Telephone='$Telephone', Passport_Number='$PassportNumber' WHERE Customer_ID='$id'";

    $result=mysql_query($sql);

    // if successfully insert data into database, go to login page.
    if($result){
        header("location:managecustomer.php");
    }
    else{
        die("ERROR EDITTING ACCOUNT:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
        echo "<a href='managecustomer.php'> <em> GO TO CUSTOMERS </em> </a>";
    }

    mysql_close($conn);
?>
