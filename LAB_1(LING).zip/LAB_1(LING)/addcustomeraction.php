<?php

    $sqlhost="127.0.0.1"; // Host name
    $sqlusername="root"; // Mysql username
    $sqlpassword=""; // Mysql password
    $db_name="lab1db"; // Database name
    $tbl_name="customertb"; // Table name

    $conn = mysql_connect("$sqlhost", "$sqlusername", "$sqlpassword");
    if(! $conn )
    {
        die("COULD NOT CONNECT TO DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
    }

    mysql_select_db("$db_name")or die("COULD NOT SELECT DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");

    // Get values from form
    $CustomerID=$_POST["txtCustomerID"];
    $AddressID=$_POST["txtAddressID"];
    $FirstName=$_POST["txtFirstName"];
    $OtherName=$_POST["txtOtherName"];
    $LastName=$_POST["txtLastName"];
    $BirthDate=$_POST["txtBirthDate"];
    $RegDate=$_POST["txtRegDate"];
    $Telephone=$_POST["txtTelephone"];
    $PassportNumber=$_POST["txtPassportNumber"];

    $sql="INSERT INTO $tbl_name(Customer_ID,Address_ID,First_Name,Other_Name,Last_Name,Birth_Date,Reg_Date,Telephone,Passport_Number)
            VALUES('$CustomerID','$AddressID','$FirstName','$OtherName','$LastName','$BirthDate','$RegDate','$Telephone','$PassportNumber')";

    $result=mysql_query($sql);

    // if successfully insert data into database
    if($result){
        header("location:managecustomer.php");
    }
    else{
        die("ERROR EDITTING ACCOUNT:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
        echo "<a href='managecustomer.php'> <em> VIEW CUSTOMERS </em> </a>";
    }

    mysql_close($conn);

?>
