<?php

    $sqlhost="127.0.0.1"; // Host name
    $sqlusername="root"; // Mysql username
    $sqlpassword=""; // Mysql password
    $db_name="lab1db"; // Database name
    $tbl_name="bankaccounttb"; // Table name

    $conn = mysql_connect("$sqlhost", "$sqlusername", "$sqlpassword");
    if(! $conn )
    {
        die("COULD NOT CONNECT TO DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
    }

    mysql_select_db("$db_name")or die("COULD NOT SELECT DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");

    // Get values from form
    $AccountID=$_POST["txtAccountID"];
    $CustomerID=$_POST["txtCustomerID"];
    $Status=$_POST["txtStatus"];
    $AccountTypeID=$_POST["txtAccountTypeID"];
    $CurrentBalance=$_POST["txtCurrentBalance"];

    $sql="INSERT INTO $tbl_name(Account_ID,Customer_ID,Status,Account_Type_ID,Current_Balance)
            VALUES('$AccountID','$CustomerID','$Status','$AccountTypeID','$CurrentBalance')";

    $result=mysql_query($sql);

    // if successfully insert data into database
    if($result){
        header("location:managebankaccount.php");
    }
    else{
        die("ERROR EDITTING ACCOUNT:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
        echo "<a href='managebankaccount.php'> <em> VIEW TICKETS </em> </a>";
    }

    mysql_close($conn);

?>
