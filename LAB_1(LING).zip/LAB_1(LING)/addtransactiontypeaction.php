<?php

    $sqlhost="127.0.0.1"; // Host name
    $sqlusername="root"; // Mysql username
    $sqlpassword=""; // Mysql password
    $db_name="lab1db"; // Database name
    $tbl_name="transactiontypetb"; // Table name

    $conn = mysql_connect("$sqlhost", "$sqlusername", "$sqlpassword");
    if(! $conn )
    {
        die("COULD NOT CONNECT TO DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
    }

    mysql_select_db("$db_name")or die("COULD NOT SELECT DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");

    // Get values from form
    $TransactionTypeID=$_POST["txtTransactionTypeID"];
    $TransactionType=$_POST["txtTransactionType"];

    $sql="INSERT INTO $tbl_name(Transaction_Type_ID,Transaction_Type)
            VALUES('$TransactionTypeID','$TransactionType')";

    $result=mysql_query($sql);

    // if successfully insert data into database
    if($result){
        header("location:managetransactiontype.php");
    }
    else{
        die("ERROR EDITING ACCOUNT:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
        echo "<a href='managetransactiontype.php'> <em> VIEW TRANSACTION </em> </a>";
    }

    mysql_close($conn);

?>
