<?php

    $sqlhost="127.0.0.1"; // Host name
    $sqlusername="root"; // Mysql username
    $sqlpassword=""; // Mysql password
    $db_name="lab1db"; // Database name
    $tbl_name="addresstb"; // Table name

    $conn = mysql_connect("$sqlhost", "$sqlusername", "$sqlpassword");
    if(! $conn )
    {
        die("COULD NOT CONNECT TO DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
    }

    mysql_select_db("$db_name")or die("COULD NOT SELECT DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");

    // Get values from form
    $AddressID=$_POST["txtAddressID"];
    $Address=$_POST["txtAddress"];
    $City=$_POST["txtCity"];
    $State=$_POST["txtState"];
    $ZipCode=$_POST["txtZipCode"];
    $Country=$_POST["txtCountry"];

    $sql="INSERT INTO $tbl_name(Address_ID,Address,City,State,Zip_Code,Country)
            VALUES('$AddressID','$Address','$City','$State','$ZipCode','$Country')";

    $result=mysql_query($sql);

    // if successfully insert data into database
    if($result){
        header("location:manageaddress.php");
    }
    else{
        die("ERROR EDITTING ACCOUNT:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
        echo "<a href='manageaddress.php'> <em> VIEW TICKETS </em> </a>";
    }

    mysql_close($conn);

?>
