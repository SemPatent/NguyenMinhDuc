<?php

    $sqlhost="127.0.0.1"; // Host name
    $sqlusername="root"; // Mysql username
    $sqlpassword=""; // Mysql password
    $db_name="lab1db"; // Database name
    $tbl_name="cardtb"; // Table name

    $conn = mysql_connect("$sqlhost", "$sqlusername", "$sqlpassword");
    if(! $conn )
    {
        die("COULD NOT CONNECT TO DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
    }

    mysql_select_db("$db_name")or die("COULD NOT SELECT DB:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");

    // Get values from form
    $CardID=$_POST["txtCardID"];
    $CardRegDate=$_POST["txtCardRegDate"];
    $AccountID=$_POST["txtAccountID"];
    $CardTypeID=$_POST["txtCardTypeID"];

    $sql="INSERT INTO $tbl_name(Card_ID,Card_Reg_Date,Account_ID,Card_Type_ID)
            VALUES('$CardID','$CardRegDate','$AccountID','$CardTypeID')";

    $result=mysql_query($sql);

    // if successfully insert data into database
    if($result){
        header("location:managecard.php");
    }
    else{
        die("ERROR EDITTING ACCOUNT:" .mysql_errno($conn) . ": " . mysql_error($conn) . "\n");
        echo "<a href='managecard.php'> <em> VIEW CARDS </em> </a>";
    }

    mysql_close($conn);

?>
